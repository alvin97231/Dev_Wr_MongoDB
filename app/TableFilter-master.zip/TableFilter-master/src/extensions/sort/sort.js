// import 'script!sortabletable';
import AdapterSortableTable from './adapterSortabletable';

if(!window.SortableTable){
    require('script!sortabletable');
}

export default AdapterSortableTable;
